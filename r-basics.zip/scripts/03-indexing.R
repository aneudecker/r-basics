# 3 Indexing ----
# - Get parts of a larger object
# - ELement of Vector / List
# - Variable of data.frame

# 3.1 `[]`

# 3.2 `$`

# 3.3 `[[]]`

# 3.4 `[,]`

# 3.5 Logical Vector

# 3.6 Example: zoo.csv
