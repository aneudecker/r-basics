# 6 Control Structures ----

# Conditional: if else

# Loop: for

# EXERCISE
# - print all numbers from 1 to 10 (with a loop)
# - print all even numbers from 2 to 20 (with a loop + conditional)
# - check if a number n is prime
# - read in multiple datasets with a loop and save in a list
#   help: get all csv files in directory with dir(path = ".", pattern = "csv")
